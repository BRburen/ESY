//
//  File.swift
//  ZBLX
//
//  Created by sia on 2017/11/3.
//  Copyright © 2017年 BR_buren1111. All rights reserved.
//

import UIKit

let kScreenW = UIScreen.main.bounds.width
let kScreenH = UIScreen.main.bounds.height

let kNavigationBarH : CGFloat = 44
let kStatusBarH : CGFloat = 20
