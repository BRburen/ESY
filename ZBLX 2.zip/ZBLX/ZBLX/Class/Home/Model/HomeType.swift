//
//  HomeType.swift
//  ZBLX
//
//  Created by sia on 2017/11/3.
//  Copyright © 2017年 BR_buren1111. All rights reserved.
//

import UIKit

class HomeType: BaseModel {
     var title : String = ""
     var type : Int = 0
}

