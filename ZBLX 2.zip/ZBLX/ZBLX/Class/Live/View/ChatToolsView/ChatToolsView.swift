//
//  ChatToolsView.swift
//  ZBLX
//
//  Created by sia on 2017/11/16.
//  Copyright © 2017年 BR_buren1111. All rights reserved.
//

import UIKit

protocol ChatToolsViewDelegate : class{
    func chatToolsView(toolView : ChatToolsView , message : String)
}

class ChatToolsView: UIView, Nibloadable {

    @IBOutlet weak var inoutTextFiled: UITextView!
    //    @IBOutlet weak var inoutTextFiled: UITextField!
    @IBOutlet weak var senMsgBtn: UIButton!
    
    weak var delegate : ChatToolsViewDelegate?
//    fileprivate lazy var emoticonBtn : UIButton = UIButton(frame: CGRect(x:300 , y: 0, width: 32, height: 32))
    @IBOutlet weak var emoticonBtn: UIButton!
    fileprivate lazy var emoticonView : EmoticonView = EmoticonView(frame: CGRect(x: 0, y: 0, width: kScreenW, height: 250))
    override func awakeFromNib() {
        super.awakeFromNib()
        inoutTextFiled.delegate = self
        setupUI()
    }
    
}
// MARK: - 监听TextView的变化而决定发送按钮的Enabled
extension ChatToolsView : UITextViewDelegate {
    func textViewDidChange(_ textView: UITextView) {
        senMsgBtn.isEnabled = textView.attributedText != nil
        print(textView.attributedText)
    }
    func textViewDidBeginEditing(_ textView: UITextView) {
        
    }
}

// MARK: - 事件监听
extension ChatToolsView {
    
    //点击发送按钮
    @IBAction func senBtnClick(_ sender: UIButton) {
        let massage = inoutTextFiled.text!
        
        //清空内容
        inoutTextFiled.text = ""
        sender.isEnabled = false
        
        //DelegateSendMassage
        self.delegate?.chatToolsView(toolView: self, message: massage)
    }
    @objc fileprivate func emoticonBtnClick(_ btn : UIButton){
        btn.isSelected = !btn.isSelected
        
        //切换键盘 (表情和文字)
//        inoutTextFiled.inputView = nil //   表示默认键盘
        
        //切换需要先 失去第一响应
        let range = inoutTextFiled.selectedTextRange    //解决光标问题
        inoutTextFiled.resignFirstResponder()
        inoutTextFiled.inputView = inoutTextFiled.inputView == nil ? emoticonView : nil   //如果是默认键盘的时候 切换成UISwitch ,UISwitch的时候切换成nil(也就是默认键盘)
        inoutTextFiled.becomeFirstResponder()
        inoutTextFiled.selectedTextRange = range    //解决光标问题
    }
}

extension ChatToolsView {
    func setupUI(){
        
        //测试代码
        /*
        let attrString = NSAttributedString(string: "hahaha", attributes: [NSForegroundColorAttributeName : UIColor.red])
        inoutTextFiled.attributedText = attrString
        */
        
        //设置表情按钮
        emoticonBtn.setImage(UIImage(named: "chat_btn_emoji"), for: .normal)
        emoticonBtn.setImage(UIImage(named: "chat_btn_keyboard"), for: .selected)
        emoticonBtn.addTarget(self, action: #selector(emoticonBtnClick(_:)), for: .touchUpInside)
        
        //给TextField设置RightView赋值
//        inoutTextFiled.rightView = emoticonBtn
//        inoutTextFiled.rightViewMode = .always
//        inoutTextFiled.allowsEditingTextAttributes = true
//        inoutTextFiled.addSubview(emoticonBtn)
        // MARK: - 闭包传值
        emoticonView.emoticonClickCallBack = {[weak self] emoticon -> Void in
            // 判断是否是删除按钮
            if emoticon.emoticonName == "delete-n"{
                self?.inoutTextFiled.deleteBackward()
                return
            }
            //获取光标的位置
//            guard let range = self?.inoutTextFiled.selectedTextRange else {return}
//            self?.inoutTextFiled.replace(range, withText: emoticon.emoticonName)
            
            //测试代码
            let attachment = NSTextAttachment()
            attachment.image = UIImage(named : emoticon.emoticonName)
//            attachment.bounds = CGRect(x: 0, y: 0, width: (self?.inoutTextFiled.font?.lineHeight)!, height: (self?.inoutTextFiled.font?.lineHeight)!)
            let attrString = NSAttributedString(attachment: attachment)
//            self?.inoutTextFiled.attributedText = attrString
            
            //获取TextView的所有文本转换成可变文本
            let mutableStr = NSMutableAttributedString(attributedString: (self?.inoutTextFiled.attributedText)!)
            let selectedRage = self?.inoutTextFiled.selectedRange
            mutableStr.insert(attrString, at: (selectedRage?.location)!)
            
            //设置新的可变文本属性,并计算新的光标
//            mutableStr.addAttributes([NSFontAttributeName : UIFont.systemFontSize], range: NSMakeRange(0, mutableStr.length))
            let newSelectedRange = NSMakeRange((selectedRage?.location)! + 1, 0)
            
            //重新给文本赋值
            self?.inoutTextFiled.attributedText = mutableStr
            //恢复光标位置 (上一句代码执行后光标会移动到最后面)
            self?.inoutTextFiled.selectedRange = newSelectedRange
        }
    }
    
}
