//
//  Emoticon.swift
//  ZBLX
//
//  Created by sia on 2017/11/16.
//  Copyright © 2017年 BR_buren1111. All rights reserved.
//  //表情模型 

import UIKit

class Emoticon {
    var emoticonName : String = ""
    init (enmoticonName : String){
        self.emoticonName = enmoticonName
    }
}
